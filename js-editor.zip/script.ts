"use strict";

import {foldGutter, getIndentUnit, HighlightStyle, indentUnit, syntaxHighlighting, syntaxTree} from "@codemirror/language";
import {esLint, javascript, javascriptLanguage, scopeCompletionSource} from "@codemirror/lang-javascript";
import {Compartment, EditorState, StateField} from "@codemirror/state";
import {basicSetup, EditorView} from "codemirror";
import {indentLess, indentMore} from "@codemirror/commands";
import {acceptCompletion} from "@codemirror/autocomplete";
import {keymap} from "@codemirror/view";
import {linter} from "@codemirror/lint";
import {Parser} from "@lezer/common";
import {tags} from "@lezer/highlight";
import {json, jsonLanguage} from "@codemirror/lang-json";
import {vscodeKeymap as oldVscodeKeymap} from "@replit/codemirror-vscode-keymap";
import {indentationMarkers} from "@replit/codemirror-indentation-markers";
import {showMinimap} from "@replit/codemirror-minimap";
import {Linter} from "eslint-linter-browserify";
import confetti from "canvas-confetti";
import tsExtensions, {tsComplete} from "./lsp";
import {showLog, clearLog, span} from "./log";
import highlight from "./highlighter";

const basicSetup2 = Array.from(basicSetup);
basicSetup2.splice(4, 1);
basicSetup2.splice(12, 2);
basicSetup2.pop();

if (new URL(document.location).searchParams.get("mod") === "1") {
    document.getElementById("debug").style.display = "";
}

const vscodeKeymap = Array.from(oldVscodeKeymap).filter(keyBinding => keyBinding.key !== "Tab");

const code = {
    "main": "",
    "drrcraft": `${JSON.stringify({
        entrypoint: "main"
    }, null, 4)}
`,
    "drrcraft-env": `${JSON.stringify({})}
`
};

const detectDocumentChanges = StateField.define({
    create() {
        return 0;
    },
    update(value, transaction) {
        if (transaction.docChanged) {
            document.querySelector(".tab.preview.active")?.classList.remove("preview");
            return value + 1;
        } else {
            return value;
        }
    }
});

const language = new Compartment();
const linterCompartment = new Compartment();
const minimapCompartment = new Compartment();
const wrappingCompartment = new Compartment();
const tabSize = new Compartment();
const indentUnitCompartment = new Compartment();

const view = new EditorView({
    state: EditorState.create({
        extensions: [
            basicSetup2,
            minimapCompartment.of([]),
            indentUnitCompartment.of(indentUnit.of("    ")),
            tabSize.of(EditorState.tabSize.of(4)),
            language.of(javascript()),
            javascriptLanguage.data.of({
                autocomplete: scopeCompletionSource(document.getElementById("completion-source-frame").contentWindow.globalThis)
            }),
            linterCompartment.of(tsExtensions),
            // linterCompartment.of(linter(esLint(new Linter(), {
            //     rules: {
            //         "constructor-super": "warn",
            //         "for-direction": "warn",
            //         "getter-return": "warn",
            //         "no-async-promise-executor": "error",
            //         "no-case-declarations": "warn",
            //         "no-class-assign": "error",
            //         "no-compare-neg-zero": "warn",
            //         "no-cond-assign": "warn",
            //         "no-const-assign": "error",
            //         "no-constant-condition": "warn",
            //         "no-control-regex": "warn",
            //         //"no-debugger": "warn",
            //         "no-delete-var": "error",
            //         "no-dupe-args": "error",
            //         "no-dupe-class-members": "error",
            //         "no-dupe-else-if": "warn",
            //         "no-dupe-keys": "warn",
            //         "no-duplicate-case": "warn",
            //         "no-empty": "warn",
            //         "no-empty-character-class": "warn",
            //         "no-empty-pattern": "warn",
            //         "no-ex-assign": "error",
            //         "no-extra-boolean-cast": "warn",
            //         "no-extra-semi": "warn",
            //         "no-fallthrough": "warn",
            //         "no-func-assign": "error",
            //         "no-global-assign": "error",
            //         "no-import-assign": "error",
            //         "no-inner-declarations": "warn",
            //         "no-invalid-regexp": "warn",
            //         "no-irregular-whitespace": "error",
            //         "no-loss-of-precision": "warn",
            //         "no-misleading-character-class": "warn",
            //         "no-mixed-spaces-and-tabs": "warn",
            //         "no-new-symbol": "error",
            //         "no-nonoctal-decimal-escape": "error",
            //         "no-obj-calls": "warn",
            //         "no-octal": "error",
            //         "no-prototype-builtins": "warn",
            //         "no-redeclare": "error",
            //         "no-regex-spaces": "warn",
            //         "no-self-assign": "warn",
            //         "no-setter-return": "warn",
            //         "no-shadow-restricted-names": "error",
            //         "no-sparse-arrays": "warn",
            //         "no-this-before-super": "error",
            //         "no-undef": "warn",
            //         "no-unexpected-multiline": "warn",
            //         "no-unreachable": "warn",
            //         "no-unsafe-finally": "warn",
            //         "no-unsafe-negation": "warn",
            //         "no-unsafe-optional-chaining": "warn",
            //         "no-unused-labels": "warn",
            //         "no-unused-vars": "warn",
            //         "no-useless-backreference": "warn",
            //         "no-useless-catch": "warn",
            //         "no-useless-escape": "warn",
            //         "no-with": "error",
            //         "require-yield": "warn",
            //         "use-isnan": "warn",
            //         "valid-typeof": "warn"
            //     },
            //     parserOptions: {
            //         ecmaVersion: "latest",
            //         sourceType: "module"
            //     },
            //     env: {
            //         browser: true
            //     }
            // }))),
            foldGutter({
                markerDOM(open) {
                    const foldGutterElement = document.createElement("span");
                    foldGutterElement.classList.add("fold-gutter-marker");
                    const svgElement = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                    svgElement.setAttribute("width", "12");
                    svgElement.setAttribute("height", "12");
                    svgElement.setAttribute("fill", "currentColor");
                    svgElement.setAttribute("viewBox", "0 0 24 24");
                    svgElement.setAttribute("preserveAspectRatio", "xMidYMin");
                    svgElement.setAttribute("xmlns", "http:\/\/www.w3.org\/2000\/svg");
                    svgElement.setAttribute("aria-hidden", "true");
                    svgElement.style.width = "0.75rem";
                    svgElement.style.height = "0.75rem";
                    svgElement.style.display = "inline-block";
                    svgElement.style.verticalAlign = "middle";
                    if (open) {
                        foldGutterElement.title = "Fold line";
                        const pathElement = document.createElementNS("http://www.w3.org/2000/svg", "path");
                        pathElement.setAttribute("d", "M12.5303 15.5303C12.2374 15.8232 11.7626 15.8232 11.4697 15.5303L5.46967 9.53033C5.17678 9.23744 5.17678 8.76256 5.46967 8.46967C5.76256 8.17678 6.23744 8.17678 6.53033 8.46967L12 13.9393L17.4697 8.46967C17.7626 8.17678 18.2374 8.17678 18.5303 8.46967C18.8232 8.76256 18.8232 9.23744 18.5303 9.53033L12.5303 15.5303Z");
                        pathElement.setAttribute("fillRule", "evenodd");
                        pathElement.setAttribute("clipRule", "evenodd");
                        svgElement.appendChild(pathElement);
                    } else {
                        foldGutterElement.title = "Unfold line";
                        const pathElement = document.createElementNS("http://www.w3.org/2000/svg", "path");
                        pathElement.setAttribute("d", "M15.5303 11.4697C15.8232 11.7626 15.8232 12.2374 15.5303 12.5303L9.53033 18.5303C9.23744 18.8232 8.76256 18.8232 8.46967 18.5303C8.17678 18.2374 8.17678 17.7626 8.46967 17.4697L13.9393 12L8.46967 6.53033C8.17678 6.23744 8.17678 5.76256 8.46967 5.46967C8.76256 5.17678 9.23744 5.17678 9.53033 5.46967L15.5303 11.4697Z");
                        pathElement.setAttribute("fillRule", "evenodd");
                        pathElement.setAttribute("clipRule", "evenodd");
                        svgElement.appendChild(pathElement);
                    }
                    foldGutterElement.appendChild(svgElement);
                    return foldGutterElement;
                }
            }),
            syntaxHighlighting(HighlightStyle.define([
                {tag: tags.url, textDecoration: "underline"},
                {tag: tags.heading1, fontSize: "1.2em", fontWeight: 600},
                {tag: tags.heading2, fontSize: "1.1em", fontWeight: 600},
                {tag: tags.heading3, fontSize: "1.05em", fontWeight: 600},
                {tag: tags.emphasis, fontStyle: "italic"},
                {tag: [tags.heading, tags.strong], fontWeight: 600},
                {tag: [tags.strikethrough, tags.deleted], textDecoration: "line-through"},
                {tag: tags.angleBracket, color: "var(--foreground-dimmest)"},
                {tag: tags.comment, color: "var(--accent-positive-default)"},
                {tag: tags.invalid, color: "var(--accent-negative-stronger)"},
                {tag: [tags.string, tags.special(tags.string), tags.character, tags.deleted], color: "var(--accent-orange-strongest)"},
                {tag: [tags.literal, tags.inserted, tags.link, tags.contentSeparator, tags.labelName, tags.function(tags.propertyName), tags.function(tags.variableName), tags.function(tags.definition(tags.variableName))], color: "var(--accent-yellow-strongest)"},
                {tag: [tags.number, tags.integer, tags.float], color: "var(--accent-lime-strongest)"},
                {tag: [tags.local(tags.variableName), tags.propertyName, tags.definition(tags.propertyName), tags.attributeName, tags.bool, tags.operator], color: "var(--accent-primary-strongest)"},
                {tag: [tags.className, tags.macroName, tags.special(tags.variableName), tags.typeName, tags.tagName, tags.meta, tags.atom, tags.keyword], color: "var(--accent-primary-stronger)"},
                {tag: tags.standard(tags.variableName), color: "var(--accent-purple-stronger)"},
                {tag: tags.namespace, color: "var(--accent-teal-strongest)"},
                {tag: [tags.regexp, tags.escape], color: "var(--accent-pink-stronger)"}
            ])),
            keymap.of([
                {key: "Mod-Enter", run},
                {key: "Tab", run: acceptCompletion},
                {key: "Tab", run({state, dispatch}) {
                    if (state.selection.ranges.some(r => !r.empty)) {
                        return indentMore({state, dispatch});
                    }
                    dispatch(state.update(state.replaceSelection(" ".repeat(getIndentUnit(state))), {
                        scrollIntoView: true,
                        userEvent: "input"
                    }));
                    return true;
                }, shift: indentLess}
            ]),
            keymap.of(vscodeKeymap),
            indentationMarkers(),
            wrappingCompartment.of(EditorView.lineWrapping),
            EditorView.clickAddsSelectionRange.of(e => e.altKey),
            detectDocumentChanges,
            linter(view => {
                let debuggerStatements = [];
                syntaxTree(view.state).cursor().iterate(node => {
                    if (node.name === "DebuggerStatement") {
                        debuggerStatements.push("d");
                    }
                });
                if (debuggerStatements.length === 0) {
                    document.getElementById("run").classList.remove("debug");
                } else {
                    document.getElementById("run").classList.add("debug");
                }
                return [];
            })
        ]
    }),
    parent: document.getElementById("editor-tab-content")
});

function saveCode() {
    code[document.querySelector(".tab.active").textContent] = view.state.doc.toString();
    requestAnimationFrame(saveCode);
}

saveCode();

document.head.appendChild(document.createElement("style")).textContent = `a:link, a:visited {
    transition: color 0.2s, text-decoration-color 0.2s;
}

a:hover, a:active {
    text-decoration-color: ${getComputedStyle(document.body).getPropertyValue("--accent-primary-stronger")}40;
}

.cm-editor .cm-selectionMatch {
    background: ${getComputedStyle(document.body).getPropertyValue("--background-highest")}80;
}

.cm-editor .cm-selectionBackground {
    background: ${getComputedStyle(document.body).getPropertyValue("--outline-stronger")}80;
}

.cm-editor.cm-focused .cm-activeLineGutter {
    background: ${getComputedStyle(document.body).getPropertyValue("--background-higher")}80;
    color: var(--foreground-default);
}

.cm-editor.cm-focused .cm-activeLine {
    background: ${getComputedStyle(document.body).getPropertyValue("--background-higher")}80;
}
`;

let runs = 0;
let frame = null;

function fixImports(code2) {
    const patches = [];
    javascriptLanguage.parser.parse(code2, {ecmaVersion: "latest", sourceType: "module"}).iterate({
        enter(node) {
            if (["ImportDeclaration", "ImportExpression", "ExportNamedDeclaration"].includes(node.name)) {
                // console.log(node.node.getChildren("String")[0])
                patches.push({
                    from: node.node.getChildren("String")[0].from + 1,
                    to: node.node.getChildren("String")[0].to - 1,
                    text: Object.fromEntries(Object.keys(code).map(key => [`./${key}`, 1])).hasOwnProperty(code2.slice(node.node.getChildren("String")[0].from + 1, node.node.getChildren("String")[0].to - 1)) ? `data:text/javascript,${encodeURIComponent(fixImports(code[code2.slice(node.node.getChildren("String")[0].from + 3, node.node.getChildren("String")[0].to - 1)]))}` : code2.slice(node.node.getChildren("String")[0].from + 1, node.node.getChildren("String")[0].to - 1)
                });
                // console.log(view.state.doc.toString().slice(0, node.node.getChildren("String")[0].from) + "xxx" + view.state.doc.toString().slice(node.node.getChildren("String")[0].to));
            }
        }
    });
    for (const patch of patches.sort((a, b) => b.from - a.from)) {
        code2 = code2.slice(0, patch.from) + patch.text + code2.slice(patch.to);
    }
    return code2;
}

function run() {
    if (runs === 0 || !document.getElementById("run").disabled) {
        document.getElementById("webview-tab-content").textContent = "";
        document.getElementById("console-output").textContent = "";
        frame = document.createElement("iframe");
        frame.src = "sandbox.html";
        let channel = new MessageChannel();
        channel.port2.addEventListener("message", e => {
            if (e.data.log) {
                showLog(e.data.elements, e.data.log);
            } else if (e.data.logClear) {
                clearLog();
            }
        });
        channel.port2.start();
        document.getElementById("webview-tab-content").appendChild(frame);
        document.getElementById("run").classList.add("ran");
        if (runs !== 0) {
            document.getElementById("run").disabled = true;
            document.querySelector("#run svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M3.25 6C3.25 4.48122 4.48122 3.25 6 3.25H18C19.5188 3.25 20.75 4.48122 20.75 6V18C20.75 19.5188 19.5188 20.75 18 20.75H6C4.48122 20.75 3.25 19.5188 3.25 18V6Z"></path>`;
            document.querySelector("#run span").textContent = "Stop";
        }
        runs++;
        frame.addEventListener("load", () => {
            document.getElementById("run").disabled = false;
            document.getElementById("run").classList.remove("working");
            document.getElementById("run").classList.remove("ran");
            document.querySelector("#run svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M20.5929 10.9105C21.4425 11.3884 21.4425 12.6116 20.5929 13.0895L6.11279 21.2345C5.27954 21.7033 4.24997 21.1011 4.24997 20.1451L4.24997 3.85492C4.24997 2.89889 5.27954 2.29675 6.11279 2.76545L20.5929 10.9105Z"></path>`;
            document.querySelector("#run span").textContent = "Run";
            try {
                const entrypoint = JSON.parse(code.drrcraft).entrypoint;
                frame.contentWindow.postMessage({
                    type: "load",
                    code: /* (view.state.doc.toString() === 'console.log("Teach us how to pay taxes");\n') ? 'console.log("Find the value of x")' :  */fixImports(code[entrypoint] ?? `class DrRcraftConfigError extends Error {
    constructor(...args) {
        super(...args);
        this.name = "DrRcraftConfigError";
    }
}

throw new DrRcraftConfigError(String.raw\`entrypoint file '${entrypoint}' does not exist\`);
`)
                }, "*", [channel.port1]);
            } catch(err) {
                frame.contentWindow.postMessage({
                    type: "load",
                    code: fixImports(`class DrRcraftConfigError extends Error {
    constructor(...args) {
        super(...args);
        this.name = "DrRcraftConfigError";
    }
}

throw new DrRcraftConfigError(String.raw\`'drrcraft' config file is malformed\`);
`)
                }, "*", [channel.port1]);
            }
        });
    }
}

run();

function button(onClick, ...text) {
    const btn = document.createElement("button");
    for (const t of text) {
        btn.appendChild(typeof t === "string" ? document.createTextNode(t) : t);
    }
    btn.className = "output-get-started-button";
    btn.addEventListener("click", onClick);
    return btn;
}

document.getElementById("run").addEventListener("click", run);

for (const button of document.querySelectorAll(".program-file")) {
    button.addEventListener("click", () => {
        code[document.querySelector(".tab.active").textContent] = view.state.doc.toString();
        view.dispatch({
            changes: {
                from: 0,
                to: view.state.doc.length,
                insert: code[button.textContent]
            },
            effects: (["drrcraft", "drrcraft-env"].includes(button.textContent)) ? [
                language.reconfigure(json()),
                linterCompartment.reconfigure([])
            ] : [
                language.reconfigure(javascript()),
                linterCompartment.reconfigure(tsExtensions)
            ]
        });
        if (["drrcraft", "drrcraft-env"].includes(button.textContent)) {
            document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M8.46967 8.46967C8.76256 8.17678 9.23744 8.17678 9.53033 8.46967L12 10.9393L14.4697 8.46967C14.7626 8.17678 15.2374 8.17678 15.5303 8.46967C15.8232 8.76256 15.8232 9.23744 15.5303 9.53033L13.0607 12L15.5303 14.4697C15.8232 14.7626 15.8232 15.2374 15.5303 15.5303C15.2374 15.8232 14.7626 15.8232 14.4697 15.5303L12 13.0607L9.53033 15.5303C9.23744 15.8232 8.76256 15.8232 8.46967 15.5303C8.17678 15.2374 8.17678 14.7626 8.46967 14.4697L10.9393 12L8.46967 9.53033C8.17678 9.23744 8.17678 8.76256 8.46967 8.46967Z" fill="var(--accent-negative-stronger)"></path>
`;
            document.querySelector("#editor-diagnostics-restart span").textContent = "No IntelliSense";
        } else {
            document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path d="M16.0892 9.22662C16.3464 9.50953 16.3255 9.94738 16.0426 10.2046L10.9657 14.82C10.7016 15.06 10.2984 15.06 10.0343 14.82L7.72662 12.7221C7.4437 12.4649 7.42285 12.027 7.68005 11.7441C7.93724 11.4612 8.37509 11.4403 8.65801 11.6975L10.5 13.3721L15.1112 9.18005C15.3941 8.92285 15.832 8.9437 16.0892 9.22662Z" fill="var(--accent-positive-stronger)"></path>
`;
            document.querySelector("#editor-diagnostics-restart span").textContent = "TypeScript";
        }
        document.querySelector(".program-file.open").classList.remove("open");
        button.classList.add("open");
        if (Array.from(document.querySelectorAll(".tab")).map(tab => tab.textContent).includes(button.textContent)) {
            document.querySelector(".tab.active").classList.remove("active");
            Array.from(document.querySelectorAll(".tab")).filter(tab => tab.textContent === button.textContent)[0].classList.add("active");
            Array.from(document.querySelectorAll(".tab")).filter(tab => tab.textContent === button.textContent)[0].scrollIntoView();
        } else {
            if (document.querySelector(".tab.preview")) {
                const previewTab = document.querySelector(".tab.preview");
                document.querySelector(".tab.active").classList.remove("active");
                previewTab.classList.add("active");
                previewTab.textContent = button.textContent;
                previewTab.scrollIntoView();
            } else {
                const newTab = document.createElement("button");
                document.querySelector(".tab.active").classList.remove("active");
                newTab.classList.add("tab");
                newTab.classList.add("preview");
                newTab.classList.add("active");
                newTab.textContent = button.textContent;
                const newTabCloseSVG = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                newTabCloseSVG.setAttribute("width", "12");
                newTabCloseSVG.setAttribute("height", "12");
                newTabCloseSVG.setAttribute("viewBox", "0 0 24 24");
                newTabCloseSVG.setAttribute("fill", "currentColor");
                newTabCloseSVG.setAttribute("aria-hidden", "true");
                const newTabCloseSVGPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
                newTabCloseSVGPath.setAttribute("fill-rule", "evenodd");
                newTabCloseSVGPath.setAttribute("clip-rule", "evenodd");
                newTabCloseSVGPath.setAttribute("d", "M5.46967 5.46967C5.76256 5.17678 6.23744 5.17678 6.53033 5.46967L12 10.9393L17.4697 5.46967C17.7626 5.17678 18.2374 5.17678 18.5303 5.46967C18.8232 5.76256 18.8232 6.23744 18.5303 6.53033L13.0607 12L18.5303 17.4697C18.8232 17.7626 18.8232 18.2374 18.5303 18.5303C18.2374 18.8232 17.7626 18.8232 17.4697 18.5303L12 13.0607L6.53033 18.5303C6.23744 18.8232 5.76256 18.8232 5.46967 18.5303C5.17678 18.2374 5.17678 17.7626 5.46967 17.4697L10.9393 12L5.46967 6.53033C5.17678 6.23744 5.17678 5.76256 5.46967 5.46967Z");
                const newTabCloseButton = document.createElement("div");
                newTabCloseButton.classList.add("tab-close");
                newTab.appendChild(newTabCloseButton).appendChild(newTabCloseSVG).appendChild(newTabCloseSVGPath);
                document.getElementById("editor-tab-bar").appendChild(document.createElement("div")).classList.add("tab-separator");
                document.getElementById("editor-tab-bar").appendChild(newTab);
                newTab.scrollIntoView();
                newTab.addEventListener("click", e => {
                    if (newTabCloseButton.contains(e.target)) {
                        e.preventDefault();
                        return;
                    }
                    //console.log(document.querySelector("#editor-tab-bar .tab.active")?.textContent.trim())
                    if (document.querySelector("#editor-tab-bar .tab.active")?.textContent.trim()) {
                        code[document.querySelector("#editor-tab-bar .tab.active")?.textContent.trim()] = view.state.doc.toString();
                    }
                    document.querySelector("#editor-tab-bar .tab.active")?.classList.remove("active");
                    newTab.classList.add("active");
                    document.querySelector(".program-file.open").classList.remove("open");
                    Array.from(document.querySelectorAll(".program-file")).filter(file => file.textContent.trim() === newTab.textContent.trim())[0].classList.add("open");
                    view.dispatch({
                        changes: {
                            from: 0,
                            to: view.state.doc.length,
                            insert: code[newTab.textContent]
                        },
                        effects: (["drrcraft", "drrcraft-env"].includes(newTab.textContent)) ? [
                            language.reconfigure(json()),
                            linterCompartment.reconfigure([])
                        ] : [
                            language.reconfigure(javascript()),
                            linterCompartment.reconfigure(tsExtensions)
                        ]
                    });
                    if (["drrcraft", "drrcraft-env"].includes(newTab.textContent)) {
                        document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M8.46967 8.46967C8.76256 8.17678 9.23744 8.17678 9.53033 8.46967L12 10.9393L14.4697 8.46967C14.7626 8.17678 15.2374 8.17678 15.5303 8.46967C15.8232 8.76256 15.8232 9.23744 15.5303 9.53033L13.0607 12L15.5303 14.4697C15.8232 14.7626 15.8232 15.2374 15.5303 15.5303C15.2374 15.8232 14.7626 15.8232 14.4697 15.5303L12 13.0607L9.53033 15.5303C9.23744 15.8232 8.76256 15.8232 8.46967 15.5303C8.17678 15.2374 8.17678 14.7626 8.46967 14.4697L10.9393 12L8.46967 9.53033C8.17678 9.23744 8.17678 8.76256 8.46967 8.46967Z" fill="var(--accent-negative-stronger)"></path>
`;
                        document.querySelector("#editor-diagnostics-restart span").textContent = "No IntelliSense";
                    } else {
                        document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path d="M16.0892 9.22662C16.3464 9.50953 16.3255 9.94738 16.0426 10.2046L10.9657 14.82C10.7016 15.06 10.2984 15.06 10.0343 14.82L7.72662 12.7221C7.4437 12.4649 7.42285 12.027 7.68005 11.7441C7.93724 11.4612 8.37509 11.4403 8.65801 11.6975L10.5 13.3721L15.1112 9.18005C15.3941 8.92285 15.832 8.9437 16.0892 9.22662Z" fill="var(--accent-positive-stronger)"></path>
`;
                        document.querySelector("#editor-diagnostics-restart span").textContent = "TypeScript";
                    }
                });
                newTabCloseButton.addEventListener("click", () => {
                    (newTab.nextElementSibling || newTab.previousElementSibling)?.remove();
                    if (newTab.classList.contains("active")) {
                        newTab.remove();
                        document.querySelector("#editor-tab-bar .tab").click();
                    } else {
                        newTab.remove();
                    }
                });
            }
        }
    });
}

document.querySelectorAll(".program-file").forEach(button => {
    if (button.textContent === "main") {
        button.click();
        document.querySelector(".tab-separator").remove();
        delete code.Webview;
        document.getElementById("webview").classList.add("active");
    }
});

document.getElementById("search-program-files").addEventListener("input", () => {
    setTimeout(() => {
        if (document.getElementById("search-program-files").value === "") {
            document.getElementById("create-program-file").style.display = "";
            document.getElementById("program-search-results-count").style.display = "none";
            document.querySelectorAll(".program-file").forEach(button => {
                button.style.display = "";
            });
            document.getElementById("configuration-files-container").style.display = "";
        } else {
            const startMilliseconds = performance.now();
            document.getElementById("create-program-file").style.display = "none";
            document.getElementById("program-search-results-count").style.display = "";
            let results = 0;
            let configurationFileResults = 0;
            document.querySelectorAll(".program-file").forEach(button => {
                if (button.textContent.toLowerCase().includes(document.getElementById("search-program-files").value.toLowerCase())) {
                    button.style.display = "";
                    results++;
                    if (document.getElementById("configuration-files-container").contains(button)) {
                        configurationFileResults++;
                    }
                } else {
                    button.style.display = "none";
                }
            });
            document.getElementById("configuration-files-container").style.display = (configurationFileResults === 0) ? "none" : "";
            const endMilliseconds = performance.now();
            document.getElementById("program-search-results-count").textContent = `${results} search result${(results === 1) ? "" : "s"} (${Math.round(endMilliseconds - startMilliseconds)} milliseconds)`;
        }
    });
});

document.querySelectorAll("#editor-tab-bar .tab").forEach(tab => {
    tab.addEventListener("click", e => {
        if (tab.querySelector(".tab-close").contains(e.target)) {
            e.preventDefault();
            return;
        }
        code[document.querySelector(".tab.active").textContent] = view.state.doc.toString();
        document.querySelector(".tab.active").classList.remove("active");
        tab.classList.add("active");
        document.querySelector(".program-file.open").classList.remove("open");
        Array.from(document.querySelectorAll(".program-file")).filter(file => file.textContent.trim() === tab.textContent.trim())[0].classList.add("open");
        view.dispatch({
            changes: {
                from: 0,
                to: view.state.doc.length,
                insert: code[tab.textContent]
            },
            effects: (["drrcraft", "drrcraft-env"].includes(tab.textContent)) ? [
                language.reconfigure(json()),
                linterCompartment.reconfigure([])
            ] : [
                language.reconfigure(javascript()),
                linterCompartment.reconfigure(tsExtensions)
            ]
        });
        if (["drrcraft", "drrcraft-env"].includes(tab.textContent)) {
            document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M8.46967 8.46967C8.76256 8.17678 9.23744 8.17678 9.53033 8.46967L12 10.9393L14.4697 8.46967C14.7626 8.17678 15.2374 8.17678 15.5303 8.46967C15.8232 8.76256 15.8232 9.23744 15.5303 9.53033L13.0607 12L15.5303 14.4697C15.8232 14.7626 15.8232 15.2374 15.5303 15.5303C15.2374 15.8232 14.7626 15.8232 14.4697 15.5303L12 13.0607L9.53033 15.5303C9.23744 15.8232 8.76256 15.8232 8.46967 15.5303C8.17678 15.2374 8.17678 14.7626 8.46967 14.4697L10.9393 12L8.46967 9.53033C8.17678 9.23744 8.17678 8.76256 8.46967 8.46967Z" fill="var(--accent-negative-stronger)"></path>
`;
            document.querySelector("#editor-diagnostics-restart span").textContent = "No IntelliSense";
        } else {
            document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path d="M16.0892 9.22662C16.3464 9.50953 16.3255 9.94738 16.0426 10.2046L10.9657 14.82C10.7016 15.06 10.2984 15.06 10.0343 14.82L7.72662 12.7221C7.4437 12.4649 7.42285 12.027 7.68005 11.7441C7.93724 11.4612 8.37509 11.4403 8.65801 11.6975L10.5 13.3721L15.1112 9.18005C15.3941 8.92285 15.832 8.9437 16.0892 9.22662Z" fill="var(--accent-positive-stronger)"></path>
`;
            document.querySelector("#editor-diagnostics-restart span").textContent = "TypeScript";
        }
    });
    tab.querySelector(".tab-close").addEventListener("click", () => {
        tab.nextElementSibling?.remove();
        if (tab.classList.contains("active")) {
            tab.remove();
            document.querySelector("#editor-tab-bar .tab").click();
        } else {
            tab.remove();
        }
    });
});

document.getElementById("create-program-file").addEventListener("click", () => {
    document.getElementById("create-program-file-container").style.display = "";
    document.getElementById("create-program-file-name").value = "";
    document.getElementById("create-program-file-name").focus();
});

document.getElementById("create-program-file-name").addEventListener("input", () => {
    if (code.hasOwnProperty(document.getElementById("create-program-file-name").value)) {
        document.querySelector("#create-program-file-error span").textContent = `A file already exists with the name '${document.getElementById("create-program-file-name").value}'`;
        document.getElementById("create-program-file-error").style.display = "";
    } else if ([".", ".."].includes(document.getElementById("create-program-file-name").value)) {
        document.querySelector("#create-program-file-error span").textContent = `'${document.getElementById("create-program-file-name").value}' is an invalid file name`;
        document.getElementById("create-program-file-error").style.display = "";
    } else if (document.getElementById("create-program-file-name").value.includes("/")) {
        document.querySelector("#create-program-file-error span").textContent = "A valid file name cannot include forward slashes";
        document.getElementById("create-program-file-error").style.display = "";
    } else if (document.getElementById("create-program-file-name").value.trim() !== document.getElementById("create-program-file-name").value) {
        document.querySelector("#create-program-file-error span").textContent = "A valid file name cannot start or end with whitespace";
        document.getElementById("create-program-file-error").style.display = "";
    } else {
        document.getElementById("create-program-file-error").style.display = "none";
    }
});

document.getElementById("create-program-file-name").addEventListener("keydown", e => {
    if (e.key === "Enter") {
        document.getElementById("create-program-file-commit").click();
    } else if (e.key === "Escape") {
        document.getElementById("create-program-file-cancel").click();
    }
});

document.getElementById("create-program-file-cancel").addEventListener("click", () => {
    document.getElementById("create-program-file-container").style.display = document.getElementById("create-program-file-error").style.display = "none";
});

document.getElementById("create-program-file-commit").addEventListener("click", () => {
    if (document.getElementById("create-program-file-name").value === "" || document.getElementById("create-program-file-error").style.display === "") {
        return;
    }
    document.getElementById("create-program-file-container").style.display = "none";
    const button = document.createElement("button");
    button.classList.add("program-file");
    button.title = button.textContent = document.getElementById("create-program-file-name").value;
    code[document.getElementById("create-program-file-name").value] = "";
    button.addEventListener("click", () => {
        code[document.querySelector(".tab.active").textContent] = view.state.doc.toString();
        view.dispatch({
            changes: {
                from: 0,
                to: view.state.doc.length,
                insert: code[button.textContent]
            },
            effects: (["drrcraft", "drrcraft-env"].includes(button.textContent)) ? [
                language.reconfigure(json()),
                linterCompartment.reconfigure([])
            ] : [
                language.reconfigure(javascript()),
                linterCompartment.reconfigure(tsExtensions)
            ]
        });
        if (["drrcraft", "drrcraft-env"].includes(button.textContent)) {
            document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M8.46967 8.46967C8.76256 8.17678 9.23744 8.17678 9.53033 8.46967L12 10.9393L14.4697 8.46967C14.7626 8.17678 15.2374 8.17678 15.5303 8.46967C15.8232 8.76256 15.8232 9.23744 15.5303 9.53033L13.0607 12L15.5303 14.4697C15.8232 14.7626 15.8232 15.2374 15.5303 15.5303C15.2374 15.8232 14.7626 15.8232 14.4697 15.5303L12 13.0607L9.53033 15.5303C9.23744 15.8232 8.76256 15.8232 8.46967 15.5303C8.17678 15.2374 8.17678 14.7626 8.46967 14.4697L10.9393 12L8.46967 9.53033C8.17678 9.23744 8.17678 8.76256 8.46967 8.46967Z" fill="var(--accent-negative-stronger)"></path>
`;
            document.querySelector("#editor-diagnostics-restart span").textContent = "No IntelliSense";
        } else {
            document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path d="M16.0892 9.22662C16.3464 9.50953 16.3255 9.94738 16.0426 10.2046L10.9657 14.82C10.7016 15.06 10.2984 15.06 10.0343 14.82L7.72662 12.7221C7.4437 12.4649 7.42285 12.027 7.68005 11.7441C7.93724 11.4612 8.37509 11.4403 8.65801 11.6975L10.5 13.3721L15.1112 9.18005C15.3941 8.92285 15.832 8.9437 16.0892 9.22662Z" fill="var(--accent-positive-stronger)"></path>
`;
            document.querySelector("#editor-diagnostics-restart span").textContent = "TypeScript";
        }
        document.querySelector(".program-file.open").classList.remove("open");
        button.classList.add("open");
        if (Array.from(document.querySelectorAll("#editor-tab-bar .tab")).map(tab => tab.textContent).includes(button.textContent)) {
            document.querySelector(".tab.active").classList.remove("active");
            Array.from(document.querySelectorAll(".tab")).filter(tab => tab.textContent === button.textContent)[0].classList.add("active");
            Array.from(document.querySelectorAll(".tab")).filter(tab => tab.textContent === button.textContent)[0].scrollIntoView();
        } else {
            if (document.querySelector(".tab.preview")) {
                const previewTab = document.querySelector(".tab.preview");
                document.querySelector(".tab.active").classList.remove("active");
                previewTab.classList.add("active");
                previewTab.textContent = button.textContent;
                previewTab.scrollIntoView();
            } else {
                const newTab = document.createElement("button");
                document.querySelector(".tab.active").classList.remove("active");
                newTab.classList.add("tab");
                newTab.classList.add("preview");
                newTab.classList.add("active");
                newTab.textContent = button.textContent;
                const newTabCloseSVG = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                newTabCloseSVG.setAttribute("width", "12");
                newTabCloseSVG.setAttribute("height", "12");
                newTabCloseSVG.setAttribute("viewBox", "0 0 24 24");
                newTabCloseSVG.setAttribute("fill", "currentColor");
                newTabCloseSVG.setAttribute("aria-hidden", "true");
                const newTabCloseSVGPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
                newTabCloseSVGPath.setAttribute("fill-rule", "evenodd");
                newTabCloseSVGPath.setAttribute("clip-rule", "evenodd");
                newTabCloseSVGPath.setAttribute("d", "M5.46967 5.46967C5.76256 5.17678 6.23744 5.17678 6.53033 5.46967L12 10.9393L17.4697 5.46967C17.7626 5.17678 18.2374 5.17678 18.5303 5.46967C18.8232 5.76256 18.8232 6.23744 18.5303 6.53033L13.0607 12L18.5303 17.4697C18.8232 17.7626 18.8232 18.2374 18.5303 18.5303C18.2374 18.8232 17.7626 18.8232 17.4697 18.5303L12 13.0607L6.53033 18.5303C6.23744 18.8232 5.76256 18.8232 5.46967 18.5303C5.17678 18.2374 5.17678 17.7626 5.46967 17.4697L10.9393 12L5.46967 6.53033C5.17678 6.23744 5.17678 5.76256 5.46967 5.46967Z");
                const newTabCloseButton = document.createElement("div");
                newTabCloseButton.classList.add("tab-close");
                newTab.appendChild(newTabCloseButton).appendChild(newTabCloseSVG).appendChild(newTabCloseSVGPath);
                document.getElementById("editor-tab-bar").appendChild(document.createElement("div")).classList.add("tab-separator");
                document.getElementById("editor-tab-bar").appendChild(newTab);
                newTab.scrollIntoView();
                newTab.addEventListener("click", e => {
                    if (newTabCloseButton.contains(e.target)) {
                        e.preventDefault();
                        return;
                    }
                    console.log(document.querySelector("#editor-tab-bar .tab.active")?.textContent.trim())
                    if (document.querySelector("#editor-tab-bar .tab.active")?.textContent.trim()) {
                        code[document.querySelector("#editor-tab-bar .tab.active")?.textContent.trim()] = view.state.doc.toString();
                    }
                    document.querySelector("#editor-tab-bar .tab.active")?.classList.remove("active");
                    newTab.classList.add("active");
                    document.querySelector(".program-file.open").classList.remove("open");
                    Array.from(document.querySelectorAll(".program-file")).filter(file => file.textContent.trim() === newTab.textContent.trim())[0].classList.add("open");
                    view.dispatch({
                        changes: {
                            from: 0,
                            to: view.state.doc.length,
                            insert: code[newTab.textContent]
                        },
                        effects: (["drrcraft", "drrcraft-env"].includes(newTab.textContent)) ? [
                            language.reconfigure(json()),
                            linterCompartment.reconfigure([])
                        ] : [
                            language.reconfigure(javascript()),
                            linterCompartment.reconfigure(tsExtensions)
                        ]
                    });
                    if (["drrcraft", "drrcraft-env"].includes(newTab.textContent)) {
                        document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M8.46967 8.46967C8.76256 8.17678 9.23744 8.17678 9.53033 8.46967L12 10.9393L14.4697 8.46967C14.7626 8.17678 15.2374 8.17678 15.5303 8.46967C15.8232 8.76256 15.8232 9.23744 15.5303 9.53033L13.0607 12L15.5303 14.4697C15.8232 14.7626 15.8232 15.2374 15.5303 15.5303C15.2374 15.8232 14.7626 15.8232 14.4697 15.5303L12 13.0607L9.53033 15.5303C9.23744 15.8232 8.76256 15.8232 8.46967 15.5303C8.17678 15.2374 8.17678 14.7626 8.46967 14.4697L10.9393 12L8.46967 9.53033C8.17678 9.23744 8.17678 8.76256 8.46967 8.46967Z" fill="var(--accent-negative-stronger)"></path>
`;
                        document.querySelector("#editor-diagnostics-restart span").textContent = "No IntelliSense";
                    } else {
                        document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path d="M16.0892 9.22662C16.3464 9.50953 16.3255 9.94738 16.0426 10.2046L10.9657 14.82C10.7016 15.06 10.2984 15.06 10.0343 14.82L7.72662 12.7221C7.4437 12.4649 7.42285 12.027 7.68005 11.7441C7.93724 11.4612 8.37509 11.4403 8.65801 11.6975L10.5 13.3721L15.1112 9.18005C15.3941 8.92285 15.832 8.9437 16.0892 9.22662Z" fill="var(--accent-positive-stronger)"></path>
`;
                        document.querySelector("#editor-diagnostics-restart span").textContent = "TypeScript";
                    }
                });
                newTabCloseButton.addEventListener("click", () => {
                    (newTab.nextElementSibling || newTab.previousElementSibling)?.remove();
                    if (newTab.classList.contains("active")) {
                        newTab.remove();
                        document.querySelector("#editor-tab-bar .tab").click();
                    } else {
                        newTab.remove();
                    }
                });
            }
        }
    });
    if (["drrcraft", "drrcraft-env"].includes(button.textContent)) {
        document.getElementById("configuration-files-container").appendChild(button);
        const configurationFiles = Array.from(document.querySelectorAll("#configuration-files-container .program-file")).sort((a, b) => (
            (a.textContent === b.textContent) ? 0
            : (a.textContent > b.textContent) ? 1
            : -1
        ));
        for (let file of document.querySelectorAll("#configuration-files-container .program-file")) {
            file.remove();
        }
        configurationFiles.forEach(file => {
            document.getElementById("configuration-files-container").appendChild(file);
        });
    } else {
        document.getElementById("program-files-container").appendChild(button);
        const programFiles = Array.from(document.querySelectorAll("#program-files-container .program-file")).sort((a, b) => (
            (a.textContent === b.textContent) ? 0
            : (a.textContent > b.textContent) ? 1
            : -1
        ));
        for (let file of document.querySelectorAll("#program-files-container .program-file")) {
            file.remove();
        }
        programFiles.forEach(file => {
            document.getElementById("program-files-container").appendChild(file);
        });
    }
    button.click();
});

let toggleSidebarButtonClicks = 0;
let toggleSidebarButtonClicksResetTimeout = null;

if (innerWidth >= 720) {
    document.getElementById("sidebar-area").style.maxWidth = document.getElementById("sidebar-area").style.padding = document.getElementById("sidebar-area").style.border = "";
    document.getElementById("toggle-sidebar").setAttribute("data-sidebar-open", "true");
    document.querySelector("#toggle-sidebar span:last-child").textContent = "Close sidebar";
    document.getElementById("sidebar-area").style.maxWidth = document.getElementById("sidebar-area").style.padding = document.getElementById("sidebar-area").style.border = "";
}

document.getElementById("toggle-sidebar").addEventListener("click", e => {
    if (document.getElementById("toggle-sidebar").getAttribute("data-sidebar-open") === "true") {
        document.getElementById("sidebar-area").style.maxWidth = document.getElementById("sidebar-area").style.padding = document.getElementById("sidebar-area").style.border = 0;
        document.getElementById("toggle-sidebar").setAttribute("data-sidebar-open", "false");
        document.querySelector("#toggle-sidebar span:last-child").textContent = "Open sidebar";
        toggleSidebarButtonClicks++;
        if (toggleSidebarButtonClicks >= 10) {
            confetti({
                disableForReducedMotion: true,
                origin: {
                    x: e.clientX / innerWidth,
                    y: e.clientY / innerHeight
                },
                spread: 360,
                ticks: 50,
                gravity: 0,
                decay: 0.94,
                startVelocity: 5,
                shapes: ["star"],
                colors: [getComputedStyle(document.body).getPropertyValue("--accent-magenta-dimmest"), getComputedStyle(document.body).getPropertyValue("--accent-magenta-dimmer"), getComputedStyle(document.body).getPropertyValue("--accent-magenta-default"), getComputedStyle(document.body).getPropertyValue("--accent-magenta-stronger"), getComputedStyle(document.body).getPropertyValue("--accent-magenta-strongest")],
                particleCount: toggleSidebarButtonClicks * 4,
                scalar: toggleSidebarButtonClicks * 0.12
            });
            confetti({
                disableForReducedMotion: true,
                origin: {
                    x: e.clientX / innerWidth,
                    y: e.clientY / innerHeight
                },
                spread: 360,
                ticks: 50,
                gravity: 0,
                decay: 0.94,
                startVelocity: 5,
                shapes: ["circle"],
                colors: [getComputedStyle(document.body).getPropertyValue("--accent-magenta-dimmest"), getComputedStyle(document.body).getPropertyValue("--accent-magenta-dimmer"), getComputedStyle(document.body).getPropertyValue("--accent-magenta-default"), getComputedStyle(document.body).getPropertyValue("--accent-magenta-stronger"), getComputedStyle(document.body).getPropertyValue("--accent-magenta-strongest")],
                particleCount: toggleSidebarButtonClicks,
                scalar: toggleSidebarButtonClicks * 0.075
            });
            document.getElementById("chimes-audio").load();
            document.getElementById("chimes-audio").play();
        }
        clearTimeout(toggleSidebarButtonClicksResetTimeout);
        toggleSidebarButtonClicksResetTimeout = setTimeout(() => {
            toggleSidebarButtonClicks = 0;
        }, 500);
    } else {
        document.getElementById("sidebar-area").style.maxWidth = document.getElementById("sidebar-area").style.padding = document.getElementById("sidebar-area").style.border = "";
        document.getElementById("toggle-sidebar").setAttribute("data-sidebar-open", "true");
        document.querySelector("#toggle-sidebar span:last-child").textContent = "Close sidebar";
    }
});

function removePreviewTabs() {
    document.querySelectorAll(".tab.preview").forEach(tab => {
        tab.classList.remove("preview");
    });
    requestAnimationFrame(removePreviewTabs);
};

requestAnimationFrame(removePreviewTabs);


document.getElementById("editor-diagnostics-restart").addEventListener("click", () => {
    let step = 0;
    let restartFinishStep = (Math.floor(Math.random() * 500)) + 250;
    view.dispatch({
        effects: linterCompartment.reconfigure([])
    });
    let diagnosticRestartFunction = () => {
        step++;
        document.getElementById("editor-diagnostics-restart").classList.add("restarting");
        document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M12 3.75C7.44365 3.75 3.75 7.44365 3.75 12C3.75 16.5563 7.44365 20.25 12 20.25C16.5563 20.25 20.25 16.5563 20.25 12C20.25 11.5858 20.5858 11.25 21 11.25C21.4142 11.25 21.75 11.5858 21.75 12C21.75 17.3848 17.3848 21.75 12 21.75C6.61522 21.75 2.25 17.3848 2.25 12C2.25 6.61522 6.61522 2.25 12 2.25C12.4142 2.25 12.75 2.58579 12.75 3C12.75 3.41421 12.4142 3.75 12 3.75Z"></path>`;
        document.querySelector("#editor-diagnostics-restart span").textContent = "Restarting...";
        if (step === restartFinishStep) {
            document.getElementById("editor-diagnostics-restart").classList.remove("restarting");
            if (["drrcraft", "drrcraft-env"].includes(document.querySelector(".tab.active").textContent)) {
                document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M8.46967 8.46967C8.76256 8.17678 9.23744 8.17678 9.53033 8.46967L12 10.9393L14.4697 8.46967C14.7626 8.17678 15.2374 8.17678 15.5303 8.46967C15.8232 8.76256 15.8232 9.23744 15.5303 9.53033L13.0607 12L15.5303 14.4697C15.8232 14.7626 15.8232 15.2374 15.5303 15.5303C15.2374 15.8232 14.7626 15.8232 14.4697 15.5303L12 13.0607L9.53033 15.5303C9.23744 15.8232 8.76256 15.8232 8.46967 15.5303C8.17678 15.2374 8.17678 14.7626 8.46967 14.4697L10.9393 12L8.46967 9.53033C8.17678 9.23744 8.17678 8.76256 8.46967 8.46967Z" fill="var(--accent-negative-stronger)"></path>
`;
                document.querySelector("#editor-diagnostics-restart span").textContent = "No IntelliSense";
            } else {
                document.querySelector("#editor-diagnostics-restart svg").innerHTML = `<path fill-rule="evenodd" clip-rule="evenodd" d="M6.25027 4.5C5.48566 4.5 4.84276 4.61742 4.31831 4.86944C3.78026 5.128 3.41275 5.50651 3.17468 5.9478C2.7488 6.73718 2.74952 7.73338 2.75009 8.51733L2.75014 8.60166C2.75014 9.50499 2.73337 10.1641 2.48714 10.6205C2.38145 10.8164 2.23331 10.9689 1.99789 11.082C1.74886 11.2017 1.36046 11.2967 0.75 11.2967C0.335786 11.2967 0 11.6116 0 12C0 12.3884 0.335786 12.7033 0.75 12.7033C1.36046 12.7033 1.74886 12.7983 1.99789 12.918C2.23331 13.0311 2.38145 13.1836 2.48714 13.3795C2.73337 13.8359 2.75014 14.495 2.75014 15.3983L2.75009 15.4827C2.74952 16.2666 2.7488 17.2628 3.17468 18.0522C3.41275 18.4935 3.78026 18.872 4.31831 19.1306C4.84276 19.3826 5.48566 19.5 6.25027 19.5C6.66448 19.5 7.00027 19.1851 7.00027 18.7967C7.00027 18.4082 6.66448 18.0933 6.25027 18.0933C5.63981 18.0933 5.25142 17.9984 5.00239 17.8787C4.76696 17.7656 4.61882 17.6131 4.51313 17.4172C4.2669 16.9608 4.25014 16.3017 4.25014 15.3983L4.25018 15.314C4.25075 14.5301 4.25147 13.5339 3.82559 12.7445C3.67573 12.4667 3.47457 12.2138 3.21187 12C3.47457 11.7862 3.67573 11.5333 3.82559 11.2555C4.25147 10.4661 4.25075 9.46995 4.25018 8.686L4.25014 8.60166C4.25014 7.69834 4.2669 7.03921 4.51313 6.58282C4.61882 6.38691 4.76696 6.23443 5.00239 6.1213C5.25142 6.00163 5.63981 5.90665 6.25027 5.90665C6.66448 5.90665 7.00027 5.59176 7.00027 5.20332C7.00027 4.81489 6.66448 4.5 6.25027 4.5ZM17.7497 4.5C17.3355 4.5 16.9997 4.81489 16.9997 5.20332C16.9997 5.59176 17.3355 5.90665 17.7497 5.90665C18.3602 5.90665 18.7486 6.00163 18.9976 6.1213C19.233 6.23443 19.3812 6.38691 19.4869 6.58282C19.7331 7.03921 19.7499 7.69834 19.7499 8.60166L19.7498 8.686C19.7493 9.46995 19.7485 10.4661 20.1744 11.2555C20.3243 11.5333 20.5254 11.7862 20.7881 12C20.5254 12.2138 20.3243 12.4667 20.1744 12.7445C19.7485 13.5339 19.7493 14.5301 19.7498 15.314L19.7499 15.3983C19.7499 16.3017 19.7331 16.9608 19.4869 17.4172C19.3812 17.6131 19.233 17.7656 18.9976 17.8787C18.7486 17.9984 18.3602 18.0933 17.7497 18.0933C17.3355 18.0933 16.9997 18.4082 16.9997 18.7967C16.9997 19.1851 17.3355 19.5 17.7497 19.5C18.5143 19.5 19.1572 19.3826 19.6817 19.1306C20.2197 18.872 20.5872 18.4935 20.8253 18.0522C21.2512 17.2628 21.2505 16.2666 21.2499 15.4827L21.2499 15.3983C21.2499 14.495 21.2666 13.8359 21.5129 13.3795C21.6185 13.1836 21.7667 13.0311 22.0021 12.918C22.2511 12.7983 22.6395 12.7033 23.25 12.7033C23.6642 12.7033 24 12.3884 24 12C24 11.6116 23.6642 11.2967 23.25 11.2967C22.6395 11.2967 22.2511 11.2017 22.0021 11.082C21.7667 10.9689 21.6185 10.8164 21.5129 10.6205C21.2666 10.1641 21.2499 9.50499 21.2499 8.60166L21.2499 8.51733C21.2505 7.73338 21.2512 6.73718 20.8253 5.9478C20.5872 5.50651 20.2197 5.128 19.6817 4.86944C19.1572 4.61742 18.5143 4.5 17.7497 4.5Z" fill="var(--foreground-dimmer)"></path>
<path d="M16.0892 9.22662C16.3464 9.50953 16.3255 9.94738 16.0426 10.2046L10.9657 14.82C10.7016 15.06 10.2984 15.06 10.0343 14.82L7.72662 12.7221C7.4437 12.4649 7.42285 12.027 7.68005 11.7441C7.93724 11.4612 8.37509 11.4403 8.65801 11.6975L10.5 13.3721L15.1112 9.18005C15.3941 8.92285 15.832 8.9437 16.0892 9.22662Z" fill="var(--accent-positive-stronger)"></path>
`;
                document.querySelector("#editor-diagnostics-restart span").textContent = "TypeScript";
            }
            view.dispatch({
                effects: linterCompartment.reconfigure(tsExtensions)
                // effects: linterCompartment.reconfigure(linter(esLint(new Linter(), {
                //     rules: {
                //         "constructor-super": "warn",
                //         "for-direction": "warn",
                //         "getter-return": "warn",
                //         "no-async-promise-executor": "error",
                //         "no-case-declarations": "warn",
                //         "no-class-assign": "error",
                //         "no-compare-neg-zero": "warn",
                //         "no-cond-assign": "warn",
                //         "no-const-assign": "error",
                //         "no-constant-condition": "warn",
                //         "no-control-regex": "warn",
                //         "no-debugger": "warn",
                //         "no-delete-var": "error",
                //         "no-dupe-args": "error",
                //         "no-dupe-class-members": "error",
                //         "no-dupe-else-if": "warn",
                //         "no-dupe-keys": "warn",
                //         "no-duplicate-case": "warn",
                //         "no-empty": "warn",
                //         "no-empty-character-class": "warn",
                //         "no-empty-pattern": "warn",
                //         "no-ex-assign": "error",
                //         "no-extra-boolean-cast": "warn",
                //         "no-extra-semi": "warn",
                //         "no-fallthrough": "warn",
                //         "no-func-assign": "error",
                //         "no-global-assign": "error",
                //         "no-import-assign": "error",
                //         "no-inner-declarations": "warn",
                //         "no-invalid-regexp": "warn",
                //         "no-irregular-whitespace": "error",
                //         "no-loss-of-precision": "warn",
                //         "no-misleading-character-class": "warn",
                //         "no-mixed-spaces-and-tabs": "warn",
                //         "no-new-symbol": "error",
                //         "no-nonoctal-decimal-escape": "error",
                //         "no-obj-calls": "warn",
                //         "no-octal": "error",
                //         "no-prototype-builtins": "warn",
                //         "no-redeclare": "error",
                //         "no-regex-spaces": "warn",
                //         "no-self-assign": "warn",
                //         "no-setter-return": "warn",
                //         "no-shadow-restricted-names": "error",
                //         "no-sparse-arrays": "warn",
                //         "no-this-before-super": "error",
                //         "no-undef": "warn",
                //         "no-unexpected-multiline": "warn",
                //         "no-unreachable": "warn",
                //         "no-unsafe-finally": "warn",
                //         "no-unsafe-negation": "warn",
                //         "no-unsafe-optional-chaining": "warn",
                //         "no-unused-labels": "warn",
                //         "no-unused-vars": "warn",
                //         "no-useless-backreference": "warn",
                //         "no-useless-catch": "warn",
                //         "no-useless-escape": "warn",
                //         "no-with": "error",
                //         "require-yield": "warn",
                //         "use-isnan": "warn",
                //         "valid-typeof": "warn"
                //     },
                //     parserOptions: {
                //         ecmaVersion: "latest",
                //         sourceType: "module"
                //     },
                //     env: {
                //         browser: true
                //     }
                // })))
            });
        } else {
            requestAnimationFrame(diagnosticRestartFunction);
        }
    };
    requestAnimationFrame(diagnosticRestartFunction);
});

document.getElementById("debug").addEventListener("click", () => {
    document.getElementById("debug-modal-container").style.display = "";
    let fileSystemData = "";
    highlight(JSON.stringify(code, null, 4), json().language, (code, classes, from, to) => {
        if (classes) {
            fileSystemData += `<span class="${classes}">${code}</span>`;
        } else {
            fileSystemData += code;
        }
    });
    document.getElementById("debug-modal-file-system").innerHTML = fileSystemData;
});

document.getElementById("debug-modal-close").addEventListener("click", () => {
    document.getElementById("debug-modal-container").style.display = "none";
});

document.getElementById("settings").addEventListener("click", () => {
    document.getElementById("settings-modal-container").style.display = "";
});

document.getElementById("settings-modal-close").addEventListener("click", () => {
    document.getElementById("settings-modal-container").style.display = "none";
});

document.getElementById("indentation-type-setting-dropdown").addEventListener("click", () => {
    document.getElementById("indentation-type-setting-dropdown-options").style.display = (document.getElementById("indentation-type-setting-dropdown-options").style.display === "none") ? "" : "none";
});

document.getElementById("minimap-setting-dropdown").addEventListener("click", () => {
    document.getElementById("minimap-setting-dropdown-options").style.display = (document.getElementById("minimap-setting-dropdown-options").style.display === "none") ? "" : "none";
});

document.getElementById("wrapping-setting-dropdown").addEventListener("click", () => {
    document.getElementById("wrapping-setting-dropdown-options").style.display = (document.getElementById("wrapping-setting-dropdown-options").style.display === "none") ? "" : "none";
});

document.querySelectorAll("#indentation-type-setting-dropdown-options .setting-dropdown-option").forEach(option => {
    option.addEventListener("click", () => {
        document.querySelector("#indentation-type-setting-dropdown-options .setting-dropdown-option.selected").classList.remove("selected");
        document.querySelector("#indentation-type-setting-dropdown span").textContent = option.textContent;
        option.classList.add("selected");
        document.getElementById("indentation-type-setting-dropdown-options").style.display = "none";
        if (option.textContent === "Spaces") {
            view.dispatch({
                effects: indentUnitCompartment.reconfigure(indentUnit.of(" ".repeat(parseInt(document.getElementById("indentation-size-slider-label").textContent))))
            });
        } else {
            view.dispatch({
                effects: indentUnitCompartment.reconfigure(indentUnit.of("\t"))
            });
        }
    });
});

document.querySelectorAll("#minimap-setting-dropdown-options .setting-dropdown-option").forEach(option => {
    option.addEventListener("click", () => {
        document.querySelector("#minimap-setting-dropdown-options .setting-dropdown-option.selected").classList.remove("selected");
        document.querySelector("#minimap-setting-dropdown span").textContent = option.textContent;
        option.classList.add("selected");
        document.getElementById("minimap-setting-dropdown-options").style.display = "none";
        if (option.textContent === "Off") {
            view.dispatch({
                effects: minimapCompartment.reconfigure([])
            });
        } else {
            view.dispatch({
                effects: minimapCompartment.reconfigure(showMinimap.compute(["doc"], state => ({
                    create: view => {
                        const dom = document.createElement("div");
                        return {dom};
                    },
                    displayText: option.textContent.toLowerCase()
                })))
            });
        }
    });
});

document.querySelectorAll("#wrapping-setting-dropdown-options .setting-dropdown-option").forEach(option => {
    option.addEventListener("click", () => {
        document.querySelector("#wrapping-setting-dropdown-options .setting-dropdown-option.selected").classList.remove("selected");
        document.querySelector("#wrapping-setting-dropdown span").textContent = option.textContent;
        option.classList.add("selected");
        document.getElementById("wrapping-setting-dropdown-options").style.display = "none";
        if (option.textContent === "Off") {
            view.dispatch({
                effects: wrappingCompartment.reconfigure([])
            });
        } else {
            view.dispatch({
                effects: wrappingCompartment.reconfigure(EditorView.lineWrapping)
            });
        }
    });
});

let indentationSizeSliderChanging = false;

document.getElementById("indentation-size-slider").addEventListener("mousedown", e => {
    indentationSizeSliderChanging = true;
    document.getElementById("indentation-size-slider").style.setProperty("--slider-size", `${Math.min(100, Math.max(0, ((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) * 100))}%`);
    view.dispatch({
        effects: [
            tabSize.reconfigure(EditorState.tabSize.of(Math.min(8, Math.max(1, Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1)))),
            (document.querySelector("#indentation-type-setting-dropdown span").textContent === "Spaces") ? indentUnitCompartment.reconfigure(indentUnit.of(" ".repeat(Math.min(8, Math.max(1, Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1))))) : indentUnitCompartment.reconfigure(indentUnit.of("\t"))
        ]
    });
    document.getElementById("indentation-size-slider-label").textContent = Math.min(8, Math.max(1, Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1));
});

document.getElementById("indentation-size-slider").addEventListener("touchstart", e => {
    indentationSizeSliderChanging = true;
    for (const touch of e.touches) {
        document.getElementById("indentation-size-slider").style.setProperty("--slider-size", `${Math.min(100, Math.max(0, ((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) * 100))}%`);
        view.dispatch({
            effects: [
                tabSize.reconfigure(EditorState.tabSize.of(Math.min(8, Math.max(1, Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1)))),
                (document.querySelector("#indentation-type-setting-dropdown span").textContent === "Spaces") ? indentUnitCompartment.reconfigure(indentUnit.of(" ".repeat(Math.min(8, Math.max(1, Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1))))) : indentUnitCompartment.reconfigure(indentUnit.of("\t"))
            ]
        });
        document.getElementById("indentation-size-slider-label").textContent = Math.min(8, Math.max(1, Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1));
    }
});

document.getElementById("indentation-size-slider").addEventListener("mouseup", e => {
    if (indentationSizeSliderChanging) {
        indentationSizeSliderChanging = false;
        document.getElementById("indentation-size-slider").classList.remove("changing");
        let size = (
            (Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) > 7) ? 7
            : (Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) < 0) ? 0
            : Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7))
        );
        document.getElementById("indentation-size-slider").style.setProperty("--slider-size", `${size * (100 / 7)}%`);
        view.dispatch({
            effects: [
                tabSize.reconfigure(EditorState.tabSize.of(size + 1)),
                (document.querySelector("#indentation-type-setting-dropdown span").textContent === "Spaces") ? indentUnitCompartment.reconfigure(indentUnit.of(" ".repeat(size + 1))) : indentUnitCompartment.reconfigure(indentUnit.of("\t"))
            ]
        });
        document.getElementById("indentation-size-slider-label").textContent = size + 1;
    }
});

document.getElementById("indentation-size-slider").addEventListener("touchend", e => {
    if (indentationSizeSliderChanging) {
        indentationSizeSliderChanging = false;
        document.getElementById("indentation-size-slider").classList.remove("changing");
        for (const touch of e.touches) {
            let size = (
                (Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) > 7) ? 7
                : (Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) < 0) ? 0
                : Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7))
            );
            document.getElementById("indentation-size-slider").style.setProperty("--slider-size", `${size * (100 / 7)}%`);
            view.dispatch({
                effects: [
                    tabSize.reconfigure(EditorState.tabSize.of(size + 1)),
                    (document.querySelector("#indentation-type-setting-dropdown span").textContent === "Spaces") ? indentUnitCompartment.reconfigure(indentUnit.of(" ".repeat(size + 1))) : indentUnitCompartment.reconfigure(indentUnit.of("\t"))
                ]
            });
            document.getElementById("indentation-size-slider-label").textContent = size + 1;
        }
    }
});

document.getElementById("indentation-size-slider").addEventListener("mouseleave", e => {
    if (indentationSizeSliderChanging) {
        document.getElementById("indentation-size-slider").classList.remove("changing");
        indentationSizeSliderChanging = false;
        let size = (
            (Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) > 7) ? 7
            : (Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) < 0) ? 0
            : Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7))
        );
        document.getElementById("indentation-size-slider").style.setProperty("--slider-size", `${size * (100 / 7)}%`);
        view.dispatch({
            effects: [
                tabSize.reconfigure(EditorState.tabSize.of(size + 1)),
                (document.querySelector("#indentation-type-setting-dropdown span").textContent === "Spaces") ? indentUnitCompartment.reconfigure(indentUnit.of(" ".repeat(size + 1))) : indentUnitCompartment.reconfigure(indentUnit.of("\t"))
            ]
        });
        document.getElementById("indentation-size-slider-label").textContent = size + 1;
    }
});

document.getElementById("indentation-size-slider").addEventListener("touchcancel", e => {
    if (indentationSizeSliderChanging) {
        document.getElementById("indentation-size-slider").classList.remove("changing");
        indentationSizeSliderChanging = false;
        for (const touch of e.touches) {
            let size = (
                (Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) > 7) ? 7
                : (Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) < 0) ? 0
                : Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7))
            );
            document.getElementById("indentation-size-slider").style.setProperty("--slider-size", `${size * (100 / 7)}%`);
            view.dispatch({
                effects: [
                    tabSize.reconfigure(EditorState.tabSize.of(size + 1)),
                    (document.querySelector("#indentation-type-setting-dropdown span").textContent === "Spaces") ? indentUnitCompartment.reconfigure(indentUnit.of(" ".repeat(size + 1))) : indentUnitCompartment.reconfigure(indentUnit.of("\t"))
                ]
            });
            document.getElementById("indentation-size-slider-label").textContent = size + 1;
        }
    }
});

document.getElementById("indentation-size-slider").addEventListener("mousemove", e => {
    if (indentationSizeSliderChanging) {
        document.getElementById("indentation-size-slider").classList.add("changing");
        document.getElementById("indentation-size-slider").style.setProperty("--slider-size", `${Math.min(100, Math.max(0, ((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) * 100))}%`);
        view.dispatch({
            effects: [
                tabSize.reconfigure(EditorState.tabSize.of(Math.min(8, Math.max(1, Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1)))),
                (document.querySelector("#indentation-type-setting-dropdown span").textContent === "Spaces") ? indentUnitCompartment.reconfigure(indentUnit.of(" ".repeat(Math.min(8, Math.max(1, Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1))))) : indentUnitCompartment.reconfigure(indentUnit.of("\t"))
            ]
        });
        document.getElementById("indentation-size-slider-label").textContent = Math.min(8, Math.max(1, Math.round(((e.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1));
    }
});

document.getElementById("indentation-size-slider").addEventListener("touchmove", e => {
    if (indentationSizeSliderChanging) {
        for (const touch of e.touches) {
            document.getElementById("indentation-size-slider").classList.add("changing");
            document.getElementById("indentation-size-slider").style.setProperty("--slider-size", `${Math.min(100, Math.max(0, ((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) * 100))}%`);
            view.dispatch({
                effects: [
                    tabSize.reconfigure(EditorState.tabSize.of(Math.min(8, Math.max(1, Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1)))),
                    (document.querySelector("#indentation-type-setting-dropdown span").textContent === "Spaces") ? indentUnitCompartment.reconfigure(indentUnit.of(" ".repeat(Math.min(8, Math.max(1, Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1))))) : indentUnitCompartment.reconfigure(indentUnit.of("\t"))
                ]
            });
            document.getElementById("indentation-size-slider-label").textContent = Math.min(8, Math.max(1, Math.round(((touch.clientX - document.getElementById("indentation-size-slider").getBoundingClientRect().x) / document.getElementById("indentation-size-slider").getBoundingClientRect().width) / (1 / 7)) + 1));
        }
    }
});

addEventListener("click", e => {
    if (document.getElementById("settings-modal-container") === e.target) {
        document.getElementById("settings-modal-container").style.display = "none";
    }
    if (document.getElementById("debug-modal-container") === e.target) {
        document.getElementById("debug-modal-container").style.display = "none";
    }
    if (!document.getElementById("indentation-type-setting-dropdown-options").contains(e.target) && !document.getElementById("indentation-type-setting-dropdown").contains(e.target)) {
        document.getElementById("indentation-type-setting-dropdown-options").style.display = "none";
    }
    if (!document.getElementById("minimap-setting-dropdown-options").contains(e.target) && !document.getElementById("minimap-setting-dropdown").contains(e.target)) {
        document.getElementById("minimap-setting-dropdown-options").style.display = "none";
    }
    if (!document.getElementById("wrapping-setting-dropdown-options").contains(e.target) && !document.getElementById("wrapping-setting-dropdown").contains(e.target)) {
        document.getElementById("wrapping-setting-dropdown-options").style.display = "none";
    }
});

addEventListener("keydown", e => {
    if (e.key === "Escape") {
        if (document.getElementById("settings-modal-container").style.display === "") {
            document.getElementById("settings-modal-container").style.display = "none";
        }
    }
});

const basicSetup3 = Array.from(basicSetup2);
basicSetup3.shift();
basicSetup3.shift();
basicSetup3.splice(10, 1);

const consoleInputView = new EditorView({
    state: EditorState.create({
        extensions: [
            basicSetup3,
            indentUnit.of("    "),
            EditorState.tabSize.of(4),
            EditorView.lineWrapping,
            javascript(),
            javascriptLanguage.data.of({
                autocomplete: scopeCompletionSource(document.getElementById("completion-source-frame").contentWindow.globalThis)
            }),
            tsExtensions,
            // linter(esLint(new Linter(), {
            //     rules: {
            //         "constructor-super": "warn",
            //         "for-direction": "warn",
            //         "getter-return": "warn",
            //         "no-async-promise-executor": "error",
            //         "no-case-declarations": "warn",
            //         "no-class-assign": "error",
            //         "no-compare-neg-zero": "warn",
            //         "no-cond-assign": "warn",
            //         "no-const-assign": "error",
            //         "no-constant-condition": "warn",
            //         "no-control-regex": "warn",
            //         //"no-debugger": "warn",
            //         "no-delete-var": "error",
            //         "no-dupe-args": "error",
            //         "no-dupe-class-members": "error",
            //         "no-dupe-else-if": "warn",
            //         "no-dupe-keys": "warn",
            //         "no-duplicate-case": "warn",
            //         "no-empty": "warn",
            //         "no-empty-character-class": "warn",
            //         "no-empty-pattern": "warn",
            //         "no-ex-assign": "error",
            //         "no-extra-boolean-cast": "warn",
            //         "no-extra-semi": "warn",
            //         "no-fallthrough": "warn",
            //         "no-func-assign": "error",
            //         "no-global-assign": "error",
            //         "no-import-assign": "error",
            //         "no-inner-declarations": "warn",
            //         "no-invalid-regexp": "warn",
            //         "no-irregular-whitespace": "error",
            //         "no-loss-of-precision": "warn",
            //         "no-misleading-character-class": "warn",
            //         "no-mixed-spaces-and-tabs": "warn",
            //         "no-new-symbol": "error",
            //         "no-nonoctal-decimal-escape": "error",
            //         "no-obj-calls": "warn",
            //         "no-octal": "error",
            //         "no-prototype-builtins": "warn",
            //         "no-redeclare": "error",
            //         "no-regex-spaces": "warn",
            //         "no-self-assign": "warn",
            //         "no-setter-return": "warn",
            //         "no-shadow-restricted-names": "error",
            //         "no-sparse-arrays": "warn",
            //         "no-this-before-super": "error",
            //         "no-undef": "warn",
            //         "no-unexpected-multiline": "warn",
            //         "no-unreachable": "warn",
            //         "no-unsafe-finally": "warn",
            //         "no-unsafe-negation": "warn",
            //         "no-unsafe-optional-chaining": "warn",
            //         "no-unused-labels": "warn",
            //         "no-unused-vars": "warn",
            //         "no-useless-backreference": "warn",
            //         "no-useless-catch": "warn",
            //         "no-useless-escape": "warn",
            //         "no-with": "error",
            //         "require-yield": "warn",
            //         "use-isnan": "warn",
            //         "valid-typeof": "warn"
            //     },
            //     parserOptions: {
            //         ecmaVersion: "latest",
            //         sourceType: "module"
            //     },
            //     env: {
            //         browser: true
            //     }
            // })),
            syntaxHighlighting(HighlightStyle.define([
                {tag: tags.url, textDecoration: "underline"},
                {tag: tags.heading1, fontSize: "1.2em", fontWeight: 600},
                {tag: tags.heading2, fontSize: "1.1em", fontWeight: 600},
                {tag: tags.heading3, fontSize: "1.05em", fontWeight: 600},
                {tag: tags.emphasis, fontStyle: "italic"},
                {tag: [tags.heading, tags.strong], fontWeight: 600},
                {tag: [tags.strikethrough, tags.deleted], textDecoration: "line-through"},
                {tag: tags.angleBracket, color: "var(--foreground-dimmest)"},
                {tag: tags.comment, color: "var(--accent-positive-default)"},
                {tag: tags.invalid, color: "var(--accent-negative-stronger)"},
                {tag: [tags.string, tags.special(tags.string), tags.character, tags.deleted], color: "var(--accent-orange-strongest)"},
                {tag: [tags.literal, tags.inserted, tags.link, tags.contentSeparator, tags.labelName, tags.function(tags.propertyName), tags.function(tags.variableName), tags.function(tags.definition(tags.variableName))], color: "var(--accent-yellow-strongest)"},
                {tag: [tags.number, tags.integer, tags.float], color: "var(--accent-lime-strongest)"},
                {tag: [tags.local(tags.variableName), tags.propertyName, tags.definition(tags.propertyName), tags.attributeName, tags.bool, tags.operator], color: "var(--accent-primary-strongest)"},
                {tag: [tags.className, tags.macroName, tags.special(tags.variableName), tags.typeName, tags.tagName, tags.meta, tags.atom, tags.keyword], color: "var(--accent-primary-stronger)"},
                {tag: tags.standard(tags.variableName), color: "var(--accent-purple-stronger)"},
                {tag: tags.namespace, color: "var(--accent-teal-strongest)"},
                {tag: [tags.regexp, tags.escape], color: "var(--accent-pink-stronger)"}
            ])),
            keymap.of([
                {key: "Tab", run: acceptCompletion},
                {key: "Enter", run() {
                    if (consoleInputView.state.doc.toString() === "") {
                        return;
                    }
                    frame.contentWindow.postMessage({
                        type: "inject",
                        code: consoleInputView.state.doc.toString()
                    });
                    consoleInputView.dispatch({
                        changes: {
                            from: 0,
                            to: consoleInputView.state.doc.length,
                            insert: ""
                        }
                    });
                }},
                {key: "Mod-Enter", run() {
                    if (consoleInputView.state.doc.toString() === "") {
                        return;
                    }
                    frame.contentWindow.postMessage({
                        type: "inject",
                        code: consoleInputView.state.doc.toString()
                    });
                    consoleInputView.dispatch({
                        changes: {
                            from: 0,
                            to: consoleInputView.state.doc.length,
                            insert: ""
                        }
                    });
                }}
            ]),
            keymap.of(vscodeKeymap),
            EditorView.clickAddsSelectionRange.of(e => e.altKey),
            EditorState.transactionFilter.of(tr => (tr.newDoc.lines === 1) ? [tr] : [])
        ]
    }),
    parent: document.getElementById("console-input-editor-container")
});

document.querySelectorAll(".holo-attribute-wrapper").forEach(element => {
    element.addEventListener("mousemove", e => {
        const w = element.clientWidth;
        const h = element.clientHeight;
        const b = element.getBoundingClientRect();
        const mX = (e.clientX - b.left) / w;
        const mY = (e.clientY - b.top) / h;
        const rX = -(mX - 0.5);
        const rY = (mY - 0.5);
        const bgX = 40 + 20 * mX;
        const bgY = 40 + 20 * mY;
        element.style.setProperty("--m-x", `${100 * mX}%`);
        element.style.setProperty("--m-y", `${100 * mY}%`);
        element.style.setProperty("--bg-x", `${bgX}%`);
        element.style.setProperty("--bg-y", `${bgY}%`);
        element.style.setProperty("--r-x", `${rX}deg`);
        element.style.setProperty("--r-y", `${rY}deg`);
    });
    element.addEventListener("mouseenter", () => {
        element.style.setProperty("--opacity", "0.6");
        const id = setTimeout(() => {
            element.style.setProperty("--duration", "0ms");
        }, 300);
        return () => {
            clearTimeout(id);
        };
    });
    element.addEventListener("mouseleave", () => {
        element.style.setProperty("--duration", "300ms");
        element.style.setProperty("--opacity", "0");
        element.style.setProperty("--m-x", "50%");
        element.style.setProperty("--m-y", "50%");
        element.style.setProperty("--bg-x", "50%");
        element.style.setProperty("--bg-y", "50%");
        element.style.setProperty("--r-x", "0deg");
        element.style.setProperty("--r-y", "0deg");
    });
});
