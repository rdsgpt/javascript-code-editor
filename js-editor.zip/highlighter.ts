import {highlightTree, tags} from "@lezer/highlight";
import {HighlightStyle} from "@codemirror/language";

const drrcraftHighlightStyle = HighlightStyle.define([
    {tag: tags.url, textDecoration: "underline"},
    {tag: tags.heading1, fontSize: "1.2em", fontWeight: 600},
    {tag: tags.heading2, fontSize: "1.1em", fontWeight: 600},
    {tag: tags.heading3, fontSize: "1.05em", fontWeight: 600},
    {tag: tags.emphasis, fontStyle: "italic"},
    {tag: [tags.heading, tags.strong], fontWeight: 600},
    {tag: [tags.strikethrough, tags.deleted], textDecoration: "line-through"},
    {tag: tags.angleBracket, color: "var(--foreground-dimmest)"},
    {tag: tags.comment, color: "var(--accent-positive-default)"},
    {tag: tags.invalid, color: "var(--accent-negative-stronger)"},
    {tag: [tags.string, tags.special(tags.string), tags.character, tags.deleted], color: "var(--accent-orange-strongest)"},
    {tag: [tags.literal, tags.inserted, tags.link, tags.contentSeparator, tags.labelName, tags.function(tags.propertyName), tags.function(tags.variableName), tags.function(tags.definition(tags.variableName))], color: "var(--accent-yellow-strongest)"},
    {tag: [tags.number, tags.integer, tags.float], color: "var(--accent-lime-strongest)"},
    {tag: [tags.local(tags.variableName), tags.propertyName, tags.definition(tags.propertyName), tags.attributeName, tags.bool, tags.operator], color: "var(--accent-primary-strongest)"},
    {tag: [tags.className, tags.macroName, tags.special(tags.variableName), tags.typeName, tags.tagName, tags.meta, tags.atom, tags.keyword], color: "var(--accent-primary-stronger)"},
    {tag: tags.standard(tags.variableName), color: "var(--accent-purple-stronger)"},
    {tag: tags.namespace, color: "var(--accent-teal-strongest)"},
    {tag: [tags.regexp, tags.escape], color: "var(--accent-pink-stronger)"}
]);

document.head.appendChild(document.createElement("style")).textContent = drrcraftHighlightStyle.module.getRules().split("\n").map(rule => `.modal-content pre ${rule}`).join("\n");

export default (code, language, callback) => {
    const tree = language.parser.parse(code);
    let pos = 0;
    highlightTree(tree, drrcraftHighlightStyle, (from, to, classes) => {
        from > pos && callback(code.slice(pos, from), null, pos, from);
        callback(code.slice(from, to), classes, from, to);
        pos = to;
    });
    pos != tree.length && callback(code.slice(pos, tree.length), null, pos, tree.length);
};
