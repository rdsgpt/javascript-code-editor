function parseStack(stack) {
    return stack.split("\n").map(line => /^\s*([\w$*.]*)/.exec(line)[1] || "<anonymous>");
}

function expandError(target, val) {
    let frames = document.createElement("div");
    frames.className = "output-traceback";
    for (let fn of parseStack(val.stack)) {
        frames.appendChild(document.createElement("div")).textContent = fn;
    }
    target.parentNode.replaceChild(frames, target);
}

function expandObj(node, val) {
    let content = document.createElement("div");
    content.className = "output-property-table";
    function addProp(name) {
        let rendered;
        try {
            rendered = renderLoggable(val[name], 40);
        } catch(err) {
            return;
        }
        content.appendChild(span("var(--accent-primary-strongest)", name, span("var(--foreground-default)", ": ")));
        content.appendChild(rendered);
    }
    if (Array.isArray(val)) {
        for (let i = 0; i < val.length; i++) addProp(String(i));
        node.parentNode.replaceChild(span(null, "[", content, "]"), node);
    } else {
        for (let prop of Object.keys(val)) addProp(prop);
        let children = ["{", content, "}"];
        if ((node.firstChild).style?.color === "var(--accent-primary-stronger)") children.unshift(node.firstChild);
        node.parentNode.replaceChild(span(null, ...children), node);
    }
}

function span(color, ...content) {
    let elt = document.createElement("span");
    elt.style.color = color ? color : "";
    for (let c of content) elt.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    return elt;
}

function etcButton(onClick) {
    let etc = document.createElement("button");
    etc.textContent = "Expand";
    etc.className = "output-expand";
    etc.onclick = onClick;
    etc.setAttribute("aria-label", "expand");
    return etc;
}

function renderLoggable(value, space, top = false) {
    if (typeof value === "number") {
        return (!Object.is(value, Math.abs(value))) ? span(null, span("var(--accent-primary-strongest)", "-"), span((value === -Infinity) ? null : "var(--accent-lime-strongest)", Math.abs(value).toString())) : span((value === Infinity || Number.isNaN(value)) ? null : "var(--accent-lime-strongest)", String(value));
    }
    if (typeof value === "bigint") {
        return (value < 0n) ? span(null, span("var(--accent-primary-strongest)", "-"), span("var(--accent-lime-strongest)", (value * -1n).toString(), "n")) : span("var(--accent-lime-strongest)", value.toString(), "n");
    }
    if (typeof value === "string") {
        return top ? document.createTextNode(value) : span("var(--accent-orange-strongest)", JSON.stringify(value));
    }
    if (typeof value === "boolean") {
        return span("var(--accent-primary-strongest)", String(value));
    }
    if (value === null) {
        return span("var(--accent-primary-stronger)", String(value));
    }
    if (value === undefined) {
        return span(null, String(value));
    }
    let {function: fun, array, object, ctor, error} = value;
    if (error) {
        return span("var(--accent-negative-stronger)", error, " ", etcButton(e => expandError(e.target, value)));
    } else if (fun) {
        return span(null, span("var(--accent-primary-stronger)", "function "), span(null, fun));
    } else if (array) {
        space -= 2;
        let children = ["["];
        let wrap;
        for (let elt of array) {
            if (children.length > 1) {
                children.push(", ");
                space -= 2;
            }
            let next = space > 0 && renderLoggable(elt, space);
            let nextSize = next ? next.textContent.length : 0;
            if (space - nextSize <= 0) {
                children.push(etcButton(() => expandObj(wrap, array)));
                break;
            }
            space -= nextSize;
            children.push(next);
        }
        children.push("]");
        return wrap = span(null, ...children);
    } else {
        space -= 2;
        let children = [];
        let wrap;
        if (ctor && ctor != "Object") {
            children.push(span("var(--accent-primary-stronger)", ctor + " "));
            space -= ctor.length + 1;
        }
        children.push("{");
        for (let prop of Object.keys(object)) {
            if (children[children.length - 1] !== "{") {
                space -= 2;
                children.push(", ");
            }
            let next = null;
            if (space > 0) {
                try {
                    next = renderLoggable(object[prop], space);
                } catch(err) {}
            }
            let nextSize = next ? prop.length + 2 + next.textContent.length : 0;
            if (!next || space - nextSize <= 0) {
                children.push(etcButton(() => expandObj(wrap, object)));
                break;
            }
            space -= nextSize;
            children.push(span("var(--accent-primary-strongest)", prop, span("var(--foreground-default)", ": ")), next);
        }
        children.push("}");
        return wrap = span(null, ...children);
    }
}

function showLog(values, type) {
    let wrap = document.createElement("div"), first = true;
    wrap.className = "log-" + type;
    for (let val of values) {
        if (first) {
            first = false;
        } else {
            wrap.appendChild(document.createTextNode(" "));
        }
        wrap.appendChild(renderLoggable(val, 60, true));
    }
    document.getElementById("console-output").appendChild(wrap);
}

function clearLog() {
    document.getElementById("console-output").textContent = "";
}

export {showLog, clearLog, span};
